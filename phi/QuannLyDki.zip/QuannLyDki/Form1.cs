﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuannLyDki
{
    public partial class Form1 : Form
    {
        DatabaseDataContext db = new DatabaseDataContext();

        

        public Form1()
        {
            InitializeComponent();
            LoadComboBoxEvents();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void LoadComboBoxEvents()
        {
            try
            {
                var events = db.Events.Select(e => new
                {
                    EventID = e.EventID,
                    Title = e.Title
                }).ToList();

                events.Insert(0, new { EventID = 0, Title = "-- Tất cả sự kiện --" });

                cbEvent.DataSource = events;
                cbEvent.DisplayMember = "Title";    // Tên hiển thị
                cbEvent.ValueMember = "EventID";    // Giá trị ẩn để lọc
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách sự kiện: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbEvent_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbEvent.SelectedValue != null)
            {
                int selectedEventID;
                if (int.TryParse(cbEvent.SelectedValue.ToString(), out selectedEventID))
                {
                    LoadDanhSach(selectedEventID);
                }
            }
        }

        private void LoadDanhSach(int eventId)
        {
            try
            {
                var query = from u in db.Users
                            join r in db.EventRegistrations on u.UserID equals r.UserID
                            select new
                            {
                                u.StudentID,
                                u.FullName,
                                u.Email,
                                r.EventID,
                                IsCheckedIn = false
                            };

                if (eventId > 0)
                {
                    query = query.Where(q => q.EventID == eventId);
                }

                var results = query.ToList();

                var danhSachHienThi = results.Select(q => new
                {
                    MSSV = q.StudentID,
                    HoTen = q.FullName,
                    Email = q.Email
                }).Distinct().ToList();

                dgvDanhSach.DataSource = danhSachHienThi;

                if (dgvDanhSach.Columns.Count > 0)
                {
                    dgvDanhSach.Columns["MSSV"].HeaderText = "Mã số SV";
                    dgvDanhSach.Columns["HoTen"].HeaderText = "Họ và Tên";
                    dgvDanhSach.Columns["Email"].HeaderText = "Địa chỉ Email";
                }

                int tong = results.Count;
                int checkin = results.Count(r => r.IsCheckedIn);
                double tyLe = tong > 0 ? Math.Round((double)checkin / tong * 100, 2) : 0;
                this.Text = $"Quản lý Tham Dự - {tong} Đăng ký ";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            int selectedEventID = 0;
            string selectedEventName = cbEvent.Text;

            if (cbEvent.SelectedValue != null)
            {
                int.TryParse(cbEvent.SelectedValue.ToString(), out selectedEventID);
            }

            FormThongKe frmTK = new FormThongKe(selectedEventID, selectedEventName);
            frmTK.ShowDialog();
        }

        private void btnXuatFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "CSV File|*.csv",
                Title = "Lưu danh sách người tham dự",
                FileName = $"DanhSach_{(cbEvent.Text == "-- Tất cả sự kiện --" ? "TatCa" : cbEvent.Text)}.csv"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, new UTF8Encoding(true)))
                    {
                        sw.WriteLine("MSSV,Họ Tên,Email");

                        var exportData = dgvDanhSach.Rows.Cast<DataGridViewRow>()
                            .Where(row => !row.IsNewRow)
                            .Select(row => $"{row.Cells["MSSV"].Value},{row.Cells["HoTen"].Value},{row.Cells["Email"].Value}");

                        foreach (var line in exportData)
                        {
                            sw.WriteLine(line);
                        }
                    }

                    MessageBox.Show("Đã xuất danh sách thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xuất file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}