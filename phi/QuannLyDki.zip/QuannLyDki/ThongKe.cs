﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace QuannLyDki
{
    public partial class FormThongKe : Form
    {
        DatabaseDataContext db = new DatabaseDataContext();
        private int eventId;

        public FormThongKe(int selectedEventId, string eventName)
        {
            InitializeComponent();
            this.eventId = selectedEventId;
            this.Text = "Thống Kê Chi Tiết - " + eventName;
        }

        private void FormThongKe_Load(object sender, EventArgs e)
        {
            LoadDuLieuThongKe();
        }

        private void LoadDuLieuThongKe()
        {
            try
            {
                var query = from u in db.Users
                            join r in db.EventRegistrations on u.UserID equals r.UserID
                            select new
                            {
                                r.EventID,
                                MSSV = u.StudentID,
                                HoTen = u.FullName,
                                GioiTinh = "Chưa cập nhật",
                                Lop = "Chưa cập nhật",
                                TrangThai = "Chỉ mới đăng ký"
                            };

                if (eventId > 0)
                {
                    query = query.Where(q => q.EventID == eventId);
                }

                dgvThongKe.DataSource = query.Select(q => new
                {
                    q.HoTen,
                    q.MSSV,
                    q.GioiTinh,
                    q.Lop,
                    q.TrangThai
                }).ToList();

                if (dgvThongKe.Columns.Count > 0)
                {
                    dgvThongKe.Columns["HoTen"].HeaderText = "Họ và Tên";
                    dgvThongKe.Columns["MSSV"].HeaderText = "Mã số SV";
                    dgvThongKe.Columns["GioiTinh"].HeaderText = "Giới tính";
                    dgvThongKe.Columns["Lop"].HeaderText = "Lớp";
                    dgvThongKe.Columns["TrangThai"].HeaderText = "Trạng thái cụ thể";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu thống kê: " + ex.Message, "Lỗi");
            }
        }
    }
}