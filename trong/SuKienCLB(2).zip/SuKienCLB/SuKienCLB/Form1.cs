﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuKienCLB
{
    public partial class Form1 : Form
    {
        Datasukien1DataContext db = new Datasukien1DataContext();
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }




        void LoadData()
        {
            dataGridView1.DataSource = null;

            var dbNew = new Datasukien1DataContext(); // tạo mới 

            var ds = dbNew.Events
                .Select(x => new
                {
                    x.EventID,
                    x.Title,
                    x.StartTime,
                    x.EndTime,
                    x.Location,
                    x.Description,
                    x.Status
                })
                .Take(50)
                .ToList();

            dataGridView1.DataSource = ds;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // KT dữ liệu
        bool ValidateForm()
        {
            List<string> loi = new List<string>();

            

            if (string.IsNullOrWhiteSpace(txtTenSK.Text))
            {
                loi.Add("Tên sự kiện");
            }

            if (dayNgayKT.Value <= dayNgayBD.Value)
            {
                loi.Add("Thời gian không hợp lệ");
            }

            if (string.IsNullOrWhiteSpace(txtDiaDiem.Text))
            {
                loi.Add("Địa điểm");
            }

            if (string.IsNullOrWhiteSpace(txtMoTa.Text))
            {
                loi.Add("Mô tả");
            }

            if (loi.Count > 0)
            {
                MessageBox.Show("Thiếu: " + string.Join(", ", loi));
                return false;
            }

            return true;
        }



        private void lbMaSK_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbNgayKT_Click(object sender, EventArgs e)
        {

        }

        private void btSuKien_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dataGridView1.Rows[e.RowIndex];

            txtMSK.Text = row.Cells["EventID"].Value.ToString();
            txtTenSK.Text = row.Cells["Title"].Value.ToString();
            dayNgayBD.Value = Convert.ToDateTime(row.Cells["StartTime"].Value);
            dayNgayKT.Value = Convert.ToDateTime(row.Cells["EndTime"].Value);
            txtDiaDiem.Text = row.Cells["Location"].Value.ToString();
            txtMoTa.Text = row.Cells["Description"].Value.ToString();
            cbTrangThai.Text = row.Cells["Status"].Value.ToString();
        }

        private void lbTenSk_Click(object sender, EventArgs e)
        {

        }

        private void txtMSK_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTenSK_TextChanged(object sender, EventArgs e)
        {

        }

        private void dayNgayBD_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dayNgayKT_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtDiaDiem_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMoTa_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_Click(object sender, EventArgs e)
        {

            if (!ValidateForm()) return;

            var ev = new Event()
            {
                Title = txtTenSK.Text,
                StartTime = dayNgayBD.Value,
                EndTime = dayNgayKT.Value,
                Location = txtDiaDiem.Text,
                Description = txtMoTa.Text,
                Status = cbTrangThai.Text
            };

            db.Events.InsertOnSubmit(ev);
            db.SubmitChanges();

            LoadData();

            MessageBox.Show("Tạo sự kiện thành công");
        }


        

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateForm()) return;

            int id = int.Parse(txtMSK.Text);

            var ev = db.Events.FirstOrDefault(x => x.EventID == id);

            if (ev == null)
            {
                MessageBox.Show("Không tìm thấy sự kiện");
                return;
            }

            ev.Title = txtTenSK.Text;
            ev.StartTime = dayNgayBD.Value;
            ev.EndTime = dayNgayKT.Value;
            ev.Location = txtDiaDiem.Text;
            ev.Description = txtMoTa.Text;
            ev.Status = cbTrangThai.Text;

            db.SubmitChanges();

            LoadData();

            MessageBox.Show("Cập nhật thành công");
        }



        private void btnDelete_Load(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMSK.Text))
            {
                MessageBox.Show("Vui lòng chọn sự kiện");
                return;
            }

            int id = int.Parse(txtMSK.Text);

            var ev = db.Events.FirstOrDefault(x => x.EventID == id);

            if (ev == null)
            {
                MessageBox.Show("Không tìm thấy sự kiện");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn xóa?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                db.Events.DeleteOnSubmit(ev);
                db.SubmitChanges();

                LoadData();

                MessageBox.Show("Xóa thành công");
            }
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var row = dataGridView1.Rows[e.RowIndex];

            txtMSK.Text = row.Cells["EventID"].Value.ToString();
            txtTenSK.Text = row.Cells["Title"].Value.ToString();
            dayNgayBD.Value = Convert.ToDateTime(row.Cells["StartTime"].Value);
            dayNgayKT.Value = Convert.ToDateTime(row.Cells["EndTime"].Value);
            txtDiaDiem.Text = row.Cells["Location"].Value.ToString();
            txtMoTa.Text = row.Cells["Description"].Value.ToString();
            cbTrangThai.Text = row.Cells["Status"].Value.ToString();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void cbTrangThai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtTimKiem_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTimKiem.Text))
            {
                LoadData();
                return;
            }

            string keyword = txtTimKiem.Text.ToLower();

            var ketQua = db.Events
                .Where(x => x.Title.ToLower().Contains(keyword))
                .Select(x => new
                {
                    x.EventID,
                    x.Title,
                    x.StartTime,
                    x.EndTime,
                    x.Location,
                    x.Description,
                    x.Status
                })
                .ToList();

            dataGridView1.DataSource = ketQua;
        }

        private void cbFilterTrangThai_SelectedIndexChanged(object sender, EventArgs e)
        {
            string trangThai = cbFilterTrangThai.Text;

            // 
            if (trangThai == "Tất cả")
            {
                LoadData();
                return;
            }

            // 
            var ketQua = db.Events
                .Where(x => x.Status == trangThai)
                .Select(x => new
                {
                    x.EventID,
                    x.Title,
                    x.StartTime,
                    x.EndTime,
                    x.Location,
                    x.Description,
                    x.Status
                })
                .ToList();

            dataGridView1.DataSource = ketQua;
        }
    }
}

