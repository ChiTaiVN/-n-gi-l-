﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuKienCLB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // event
        class Event
        {
            public string MaSK { get; set; }
            public string TenSK { get; set; }
            public DateTime NgayBD { get; set; }
            public DateTime NgayKT { get; set; }
            public string DiaDiem { get; set; }
            public string MoTa { get; set; }

            public string TrangThai { get; set; }
        }

        List<Event> danhSach = new List<Event>();
        int selectedIndex = -1;


        void LoadData()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = danhSach.Take(50).ToList();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // KT dữ liệu
        bool ValidateForm()
        {
            List<string> loi = new List<string>();

            if (string.IsNullOrWhiteSpace(txtMSK.Text))
            {
                loi.Add("Mã sự kiện");
            }

            if (string.IsNullOrWhiteSpace(txtTenSK.Text))
            {
                loi.Add("Tên sự kiện");
            }

            if (dayNgayKT.Value <= dayNgayBD.Value)
            {
                loi.Add("Thời gian không hợp lệ");
            }

            if (string.IsNullOrWhiteSpace(txtDiaDiem.Text))
            {
                loi.Add("Địa điểm");
            }

            if (string.IsNullOrWhiteSpace(txtMoTa.Text))
            {
                loi.Add("Mô tả");
            }

            if (loi.Count > 0)
            {
                MessageBox.Show("Thiếu: " + string.Join(", ", loi));
                return false;
            }

            return true;
        }



        private void lbMaSK_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbNgayKT_Click(object sender, EventArgs e)
        {

        }

        private void btSuKien_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedIndex = e.RowIndex;

                var ev = danhSach[selectedIndex];

                txtMSK.Text = ev.MaSK;
                txtTenSK.Text = ev.TenSK;
                dayNgayBD.Value = ev.NgayBD;
                dayNgayKT.Value = ev.NgayKT;
                txtDiaDiem.Text = ev.DiaDiem;
                txtMoTa.Text = ev.MoTa;
                danhSach[selectedIndex].TrangThai = cbTrangThai.SelectedItem?.ToString();

            }
        }

        private void lbTenSk_Click(object sender, EventArgs e)
        {

        }

        private void txtMSK_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTenSK_TextChanged(object sender, EventArgs e)
        {

        }

        private void dayNgayBD_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dayNgayKT_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtDiaDiem_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMoTa_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_Click(object sender, EventArgs e)
        {

            if (!ValidateForm()) return;
            
            Event ev = new Event()
            {

                MaSK = txtMSK.Text,
                TenSK = txtTenSK.Text,
                NgayBD = dayNgayBD.Value,
                NgayKT = dayNgayKT.Value,
                DiaDiem = txtDiaDiem.Text,
                MoTa = txtMoTa.Text,
                TrangThai = cbTrangThai.Text
            };

            danhSach.Add(ev);
            LoadData();
            
            

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateForm()) return; 
            
            if (selectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn sự kiện để sửa");
                return;
            }

            danhSach[selectedIndex].MaSK = txtMSK.Text;
            danhSach[selectedIndex].TenSK = txtTenSK.Text;
            danhSach[selectedIndex].NgayBD = dayNgayBD.Value;
            danhSach[selectedIndex].NgayKT = dayNgayKT.Value;
            danhSach[selectedIndex].DiaDiem = txtDiaDiem.Text;
            danhSach[selectedIndex].MoTa = txtMoTa.Text;
            danhSach[selectedIndex].TrangThai = cbTrangThai.SelectedItem?.ToString();

            LoadData();

            MessageBox.Show("Cập nhật thành công");

            

        }

        private void btnDelete_Load(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedIndex < 0)
            {
                MessageBox.Show("Vui lòng chọn sự kiện cần xóa!");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn xóa sự kiện này?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                danhSach.RemoveAt(selectedIndex);
                LoadData();

                MessageBox.Show("Xóa thành công");
                selectedIndex = -1;
            }
        }

        
            private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            selectedIndex = e.RowIndex;

            var ev = danhSach[selectedIndex];

            txtMSK.Text = ev.MaSK;
            txtTenSK.Text = ev.TenSK;
            dayNgayBD.Value = ev.NgayBD;
            dayNgayKT.Value = ev.NgayKT;
            txtDiaDiem.Text = ev.DiaDiem;
            txtMoTa.Text = ev.MoTa;
            cbTrangThai.SelectedItem = ev.TrangThai;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void cbTrangThai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtTimKiem_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.ToLower();

            var ketQua = danhSach.Where(x =>
                x.TenSK.ToLower().Contains(keyword)
            ).ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = ketQua;
        }

        private void cbFilterTrangThai_SelectedIndexChanged(object sender, EventArgs e)
        {
            string trangThai = cbFilterTrangThai.Text;

            var ketQua = danhSach.Where(x =>
                string.IsNullOrEmpty(trangThai) || x.TrangThai == trangThai
            ).ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = ketQua;
        }
    }
    }

