﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Checkin_feedback
{
    public partial class main : Form
    {
        string connStr = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        public main()
        {
            InitializeComponent();
        }

        private void btncheckin_Click(object sender, EventArgs e)
        {
            string mssv = txtmssv.Text.Trim();
string mave = txtmave.Text.Trim();
string eventId = txtmasukiencheckin.Text.Trim();

if (string.IsNullOrEmpty(eventId))
{
    MessageBox.Show("Vui lòng nhập mã sự kiện!");
    return;
}

if (string.IsNullOrEmpty(mssv) && string.IsNullOrEmpty(mave))
{
    MessageBox.Show("Nhập MSSV hoặc Mã vé!");
    return;
}

string input = !string.IsNullOrEmpty(mssv) ? mssv : mave;

using (SqlConnection conn = new SqlConnection(connStr))
{
    conn.Open();

                string query;

              

                if (!string.IsNullOrEmpty(mssv))
                {
                    query = @"SELECT er.*
              FROM EventRegistration er
              JOIN [User] u ON er.UserID = u.UserID
              WHERE u.StudentID = @input
              AND er.EventID = @eventId";
                }
                else
                {
                    query = @"SELECT * FROM EventRegistration
              WHERE QRCodeString = @input
              AND EventID = @eventId";
                }

                SqlCommand cmd = new SqlCommand(query, conn);
    cmd.Parameters.AddWithValue("@input", input);
    cmd.Parameters.AddWithValue("@eventId", eventId);

    SqlDataReader reader = cmd.ExecuteReader();

    if (!reader.Read())
    {
                    reader.Close();
                    MessageBox.Show("Không tìm thấy!");
        return;
    }

    bool isChecked = reader["IsCheckedIn"] != DBNull.Value && Convert.ToBoolean(reader["IsCheckedIn"]);

    if (isChecked)
    {
                    reader.Close();
                    MessageBox.Show("Đã check-in trước đó!");
        return;
    }

    reader.Close();

    string update;
                if (!string.IsNullOrEmpty(mssv))
                {
                    update = @"UPDATE er
               SET IsCheckedIn = 1,
                   CheckInTime = GETDATE()
               FROM EventRegistration er
               JOIN [User] u ON er.UserID = u.UserID
               WHERE u.StudentID = @input
               AND er.EventID = @eventId";
                }
                else
                {
                    update = @"UPDATE EventRegistration
               SET IsCheckedIn = 1,
                   CheckInTime = GETDATE()
               WHERE QRCodeString = @input
               AND EventID = @eventId";
                }



                SqlCommand cmdUpdate = new SqlCommand(update, conn);
    cmdUpdate.Parameters.AddWithValue("@input", input);
    cmdUpdate.Parameters.AddWithValue("@eventId", eventId);

    cmdUpdate.ExecuteNonQuery();

    MessageBox.Show("Check-in thành công!");
}
        }

        private void txtmssv_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtmave_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtdanhgia_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtmask_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbmask_Click(object sender, EventArgs e)
        {

        }

        private void txtmasukiencheckin_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtComment_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbgopy_Click(object sender, EventArgs e)
        {

        }

        private void txtmaskcheckin_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtmasukiencheckin_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btndanhgia_Click(object sender, EventArgs e)
        {
            string mssv = txtmssv.Text.Trim();
            string eventId = txtmasukiencheckin.Text.Trim();
            string rating = txtdanhgia.Text.Trim();
            string comment = txtComment.Text.Trim();

            if (string.IsNullOrEmpty(mssv) || string.IsNullOrEmpty(eventId) || string.IsNullOrEmpty(rating))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                string check = @"SELECT er.*
                     FROM EventRegistration er
                     JOIN [User] u ON er.UserID = u.UserID
                     WHERE u.StudentID = @mssv
                     AND er.EventID = @eventId
                     AND er.IsCheckedIn = 1";

                SqlCommand cmdCheck = new SqlCommand(check, conn);
                cmdCheck.Parameters.AddWithValue("@mssv", mssv);
                cmdCheck.Parameters.AddWithValue("@eventId", eventId);

                SqlDataReader reader = cmdCheck.ExecuteReader();

                if (!reader.Read())
                {
                    reader.Close();
                    MessageBox.Show("Bạn chưa check-in nên không thể đánh giá!");
                    return;
                }

                reader.Close();

                string insert = @"INSERT INTO Feedback(EventID, UserID, Rating, Comment)
                      VALUES(@eventId,
                             (SELECT UserID FROM [User] WHERE StudentID = @mssv),
                             @rating,
                             @comment)";

                SqlCommand cmdInsert = new SqlCommand(insert, conn);
                cmdInsert.Parameters.AddWithValue("@eventId", eventId);
                cmdInsert.Parameters.AddWithValue("@mssv", mssv);
                cmdInsert.Parameters.AddWithValue("@rating", rating);
                cmdInsert.Parameters.AddWithValue("@comment", comment);

                cmdInsert.ExecuteNonQuery();

                MessageBox.Show("Gửi đánh giá thành công!");
            }
        }
    }
}
/*
MSSV: 490101002
Mã vé: QR_EV3_US4_99999
Mã sự kiện: 3 */ 
