﻿namespace SuKienCLB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btSuKien = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbMaSK = new System.Windows.Forms.Label();
            this.lbTenSk = new System.Windows.Forms.Label();
            this.lbNgayBD = new System.Windows.Forms.Label();
            this.lbNgayKT = new System.Windows.Forms.Label();
            this.lbDiaDiem = new System.Windows.Forms.Label();
            this.lbMoTa = new System.Windows.Forms.Label();
            this.txtMSK = new System.Windows.Forms.TextBox();
            this.txtTenSK = new System.Windows.Forms.TextBox();
            this.dayNgayBD = new System.Windows.Forms.DateTimePicker();
            this.dayNgayKT = new System.Windows.Forms.DateTimePicker();
            this.txtDiaDiem = new System.Windows.Forms.TextBox();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btSuKien);
            this.panel1.Location = new System.Drawing.Point(19, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 1039);
            this.panel1.TabIndex = 0;
            // 
            // btSuKien
            // 
            this.btSuKien.Location = new System.Drawing.Point(14, 33);
            this.btSuKien.Name = "btSuKien";
            this.btSuKien.Size = new System.Drawing.Size(159, 80);
            this.btSuKien.TabIndex = 0;
            this.btSuKien.Text = "Sự Kiện";
            this.btSuKien.UseVisualStyleBackColor = true;
            this.btSuKien.Click += new System.EventHandler(this.btSuKien_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnEdit);
            this.panel2.Controls.Add(this.btnThem);
            this.panel2.Controls.Add(this.txtMoTa);
            this.panel2.Controls.Add(this.txtDiaDiem);
            this.panel2.Controls.Add(this.dayNgayKT);
            this.panel2.Controls.Add(this.dayNgayBD);
            this.panel2.Controls.Add(this.txtTenSK);
            this.panel2.Controls.Add(this.txtMSK);
            this.panel2.Controls.Add(this.lbMoTa);
            this.panel2.Controls.Add(this.lbDiaDiem);
            this.panel2.Controls.Add(this.lbNgayKT);
            this.panel2.Controls.Add(this.lbNgayBD);
            this.panel2.Controls.Add(this.lbTenSk);
            this.panel2.Controls.Add(this.lbMaSK);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Location = new System.Drawing.Point(234, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1422, 1034);
            this.panel2.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1390, 360);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lbMaSK
            // 
            this.lbMaSK.AutoSize = true;
            this.lbMaSK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaSK.Location = new System.Drawing.Point(46, 411);
            this.lbMaSK.Name = "lbMaSK";
            this.lbMaSK.Size = new System.Drawing.Size(172, 33);
            this.lbMaSK.TabIndex = 1;
            this.lbMaSK.Text = "Mã Sự Kiện:";
            this.lbMaSK.Click += new System.EventHandler(this.lbMaSK_Click);
            // 
            // lbTenSk
            // 
            this.lbTenSk.AutoSize = true;
            this.lbTenSk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenSk.Location = new System.Drawing.Point(46, 484);
            this.lbTenSk.Name = "lbTenSk";
            this.lbTenSk.Size = new System.Drawing.Size(182, 33);
            this.lbTenSk.TabIndex = 3;
            this.lbTenSk.Text = "Tên Sự Kiện:";
            this.lbTenSk.Click += new System.EventHandler(this.lbTenSk_Click);
            // 
            // lbNgayBD
            // 
            this.lbNgayBD.AutoSize = true;
            this.lbNgayBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayBD.Location = new System.Drawing.Point(46, 561);
            this.lbNgayBD.Name = "lbNgayBD";
            this.lbNgayBD.Size = new System.Drawing.Size(211, 33);
            this.lbNgayBD.TabIndex = 4;
            this.lbNgayBD.Text = "Ngày Bắt Đầu :";
            // 
            // lbNgayKT
            // 
            this.lbNgayKT.AutoSize = true;
            this.lbNgayKT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayKT.Location = new System.Drawing.Point(46, 637);
            this.lbNgayKT.Name = "lbNgayKT";
            this.lbNgayKT.Size = new System.Drawing.Size(223, 33);
            this.lbNgayKT.TabIndex = 5;
            this.lbNgayKT.Text = "Ngày Kết Thúc :";
            this.lbNgayKT.Click += new System.EventHandler(this.lbNgayKT_Click);
            // 
            // lbDiaDiem
            // 
            this.lbDiaDiem.AutoSize = true;
            this.lbDiaDiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiaDiem.Location = new System.Drawing.Point(46, 724);
            this.lbDiaDiem.Name = "lbDiaDiem";
            this.lbDiaDiem.Size = new System.Drawing.Size(265, 33);
            this.lbDiaDiem.TabIndex = 6;
            this.lbDiaDiem.Text = "Địa Điểm Diễn Ra :";
            this.lbDiaDiem.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbMoTa
            // 
            this.lbMoTa.AutoSize = true;
            this.lbMoTa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoTa.Location = new System.Drawing.Point(46, 811);
            this.lbMoTa.Name = "lbMoTa";
            this.lbMoTa.Size = new System.Drawing.Size(103, 33);
            this.lbMoTa.TabIndex = 7;
            this.lbMoTa.Text = "Mô tả :";
            // 
            // txtMSK
            // 
            this.txtMSK.Location = new System.Drawing.Point(359, 415);
            this.txtMSK.Name = "txtMSK";
            this.txtMSK.Size = new System.Drawing.Size(380, 31);
            this.txtMSK.TabIndex = 8;
            this.txtMSK.TextChanged += new System.EventHandler(this.txtMSK_TextChanged);
            // 
            // txtTenSK
            // 
            this.txtTenSK.Location = new System.Drawing.Point(359, 488);
            this.txtTenSK.Name = "txtTenSK";
            this.txtTenSK.Size = new System.Drawing.Size(380, 31);
            this.txtTenSK.TabIndex = 9;
            this.txtTenSK.TextChanged += new System.EventHandler(this.txtTenSK_TextChanged);
            // 
            // dayNgayBD
            // 
            this.dayNgayBD.Location = new System.Drawing.Point(359, 561);
            this.dayNgayBD.Name = "dayNgayBD";
            this.dayNgayBD.Size = new System.Drawing.Size(380, 31);
            this.dayNgayBD.TabIndex = 10;
            this.dayNgayBD.ValueChanged += new System.EventHandler(this.dayNgayBD_ValueChanged);
            // 
            // dayNgayKT
            // 
            this.dayNgayKT.Location = new System.Drawing.Point(359, 637);
            this.dayNgayKT.Name = "dayNgayKT";
            this.dayNgayKT.Size = new System.Drawing.Size(380, 31);
            this.dayNgayKT.TabIndex = 11;
            this.dayNgayKT.ValueChanged += new System.EventHandler(this.dayNgayKT_ValueChanged);
            // 
            // txtDiaDiem
            // 
            this.txtDiaDiem.Location = new System.Drawing.Point(359, 726);
            this.txtDiaDiem.Name = "txtDiaDiem";
            this.txtDiaDiem.Size = new System.Drawing.Size(380, 31);
            this.txtDiaDiem.TabIndex = 12;
            this.txtDiaDiem.TextChanged += new System.EventHandler(this.txtDiaDiem_TextChanged);
            // 
            // txtMoTa
            // 
            this.txtMoTa.Location = new System.Drawing.Point(359, 811);
            this.txtMoTa.Name = "txtMoTa";
            this.txtMoTa.Size = new System.Drawing.Size(380, 31);
            this.txtMoTa.TabIndex = 13;
            this.txtMoTa.TextChanged += new System.EventHandler(this.txtMoTa_TextChanged);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(52, 937);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(199, 66);
            this.btnThem.TabIndex = 14;
            this.btnThem.Text = "Thêm Sự Kiện";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(359, 927);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(199, 66);
            this.btnEdit.TabIndex = 15;
            this.btnEdit.Text = "Chỉnh Sửa Sự Kiện";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(691, 927);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(199, 66);
            this.btnDelete.TabIndex = 16;
            this.btnDelete.Text = "Xóa Sự Kiện";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1667, 1071);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Sự Kiện";
            this.Load += new System.EventHandler(this.btnDelete_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btSuKien;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbMaSK;
        private System.Windows.Forms.Label lbMoTa;
        private System.Windows.Forms.Label lbDiaDiem;
        private System.Windows.Forms.Label lbNgayKT;
        private System.Windows.Forms.Label lbNgayBD;
        private System.Windows.Forms.Label lbTenSk;
        private System.Windows.Forms.TextBox txtMSK;
        private System.Windows.Forms.TextBox txtTenSK;
        private System.Windows.Forms.DateTimePicker dayNgayBD;
        private System.Windows.Forms.DateTimePicker dayNgayKT;
        private System.Windows.Forms.TextBox txtDiaDiem;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
    }
}

