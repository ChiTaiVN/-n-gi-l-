﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Agile
{
    public partial class FormCreateAccount : Form
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;

        public FormCreateAccount()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormCreateAccount_Load(object sender, EventArgs e)
        {
            // Nạp data cho ComboBox Phân quyền
            cbRole.Items.Add(new { Text = "Admin CLB", Value = 1 });
            cbRole.Items.Add(new { Text = "Ban Tổ Chức", Value = 2 });
            cbRole.Items.Add(new { Text = "Sinh Viên", Value = 3 });
            cbRole.DisplayMember = "Text";
            cbRole.ValueMember = "Value";
        }

        private void btnTaoTaiKhoan_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string mssv = txtMSSV.Text.Trim();
            string email = txtEmail.Text.Trim();

            // Validate rỗng
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) || cbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng điền đủ các trường bắt buộc!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    // 1. Kiểm tra trùng MSSV hoặc Email
                    string checkQuery = "SELECT COUNT(*) FROM [User] WHERE Email = @Email OR (StudentID = @MSSV AND @MSSV <> '')";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@Email", email);
                    checkCmd.Parameters.AddWithValue("@MSSV", mssv);

                    int count = (int)checkCmd.ExecuteScalar();
                    if (count > 0)
                    {
                        MessageBox.Show("MSSV hoặc Email đã tồn tại trên hệ thống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        // Đổi màu nền cảnh báo theo yêu cầu AC
                        txtEmail.BackColor = System.Drawing.Color.LightPink;
                        return;
                    }

                    // 2. Tạo mật khẩu mặc định và Insert
                    string defaultPass = "123456"; // Hoặc Random
                    int roleId = (int)((dynamic)cbRole.SelectedItem).Value;

                    string insertQuery = "INSERT INTO [User] (RoleID, StudentID, FullName, Email, PasswordHash, IsActive) VALUES (@RoleID, @MSSV, @FullName, @Email, @Pass, 1)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                    insertCmd.Parameters.AddWithValue("@RoleID", roleId);
                    insertCmd.Parameters.AddWithValue("@MSSV", string.IsNullOrEmpty(mssv) ? (object)DBNull.Value : mssv);
                    insertCmd.Parameters.AddWithValue("@FullName", fullName);
                    insertCmd.Parameters.AddWithValue("@Email", email);
                    insertCmd.Parameters.AddWithValue("@Pass", defaultPass); // Nên dùng thư viện Hash

                    insertCmd.ExecuteNonQuery();

                    // 3. Thông báo thành công và gửi Email (Mock)
                    MessageBox.Show("Tạo tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show($"Hệ thống đã tự động gửi email chứa Tên đăng nhập ({email}) và mật khẩu đến thành viên mới.", "Gửi Email Thành Công");

                    this.Close(); // Đóng form sau khi tạo xong
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi kết nối CSDL: " + ex.Message);
                }
            }
        }
    }
}