﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Agile
{
    public partial class FormLogin : Form
    {
        // Lấy chuỗi kết nối từ App.config
        string connStr = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;

        public FormLogin()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim(); // Email hoặc MSSV
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập Email/MSSV và Mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                // Truy vấn kiểm tra đăng nhập theo Email hoặc MSSV
                string query = @"SELECT RoleID FROM [User] 
                                 WHERE (Email = @Username OR StudentID = @Username) 
                                 AND PasswordHash = @Password AND IsActive = 1";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password); // Thực tế nên dùng Hash, nhưng sprint này tạm so sánh chuỗi

                try
                {
                    conn.Open();
                    object result = cmd.ExecuteScalar(); // Lấy RoleID

                    if (result != null)
                    {
                        int roleId = Convert.ToInt32(result);
                        MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Điều hướng thông minh
                        this.Hide();
                        if (roleId == 3 || roleId == 4) // 3: Sinh viên, 4: Khách mời
                        {
                            // FormSinhVien frmSV = new FormSinhVien();
                            // frmSV.Show();
                            MessageBox.Show("Chuyển hướng -> Trang chủ Sự kiện", "Điều hướng");
                        }
                        else // Admin, BTC, Cố vấn
                        {
                            // FormAdminDashboard frmAdmin = new FormAdminDashboard();
                            // frmAdmin.Show();
                            MessageBox.Show("Chuyển hướng -> Dashboard Quản trị", "Điều hướng");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Email hoặc mật khẩu không chính xác!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi kết nối CSDL: " + ex.Message);
                }
            }
        }
    }
}