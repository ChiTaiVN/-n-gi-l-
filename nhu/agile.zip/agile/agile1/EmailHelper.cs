﻿using System;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

public class EmailHelper
{
    public static void Send(string toEmail, string eventName, string time, string location)
    {
        try
        {
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress("your_email@gmail.com");
            mail.To.Add(toEmail);
            mail.Subject = "Xác nhận đăng ký sự kiện";

            mail.Body = $@"
                Chào bạn,

                Bạn đã đăng ký thành công:

                - Tên sự kiện: {eventName}
                - Thời gian: {time}
                - Địa điểm: {location}

                Cảm ơn bạn!
                ";

            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.Credentials = new NetworkCredential("your_email@gmail.com", "your_app_password");
            smtp.EnableSsl = true;

            smtp.Send(mail);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Lỗi gửi mail: " + ex.Message);
        }
    }
}