﻿using System;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace agile1
{
    public partial class StudentDetail : Form
    {
        databaseDataContext db = new databaseDataContext();
        int userID;

        public StudentDetail(int id)
        {
            InitializeComponent();
            userID = id;

            this.Load += StudentDetail_Load;
            btnSave.Click += btnSave_Click;
            btnRegister.Click += btnRegister_Click;

            // setup DataGridView
            dgvHistory.AutoGenerateColumns = false;
            dgvHistory.Columns.Clear();

            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn()
            {
                Name = "colEventName",
                HeaderText = "Tên sự kiện",
                DataPropertyName = "EventName",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn()
            {
                Name = "colStatus",
                HeaderText = "Trạng thái",
                DataPropertyName = "Status",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            dgvHistory.CellFormatting += dgvHistory_CellFormatting;
        }

        // ================= LOAD FORM =================
        private void StudentDetail_Load(object sender, EventArgs e)
        {
            LoadUser();
            LoadHistory();
            LoadEvents();
        }

        // ================= LOAD USER =================
        void LoadUser()
        {
            var u = db.Users.FirstOrDefault(x => x.UserID == userID);

            if (u == null)
            {
                MessageBox.Show("Không tìm thấy sinh viên!");
                return;
            }

            txtMSSV.Text = u.StudentID ?? "";
            txtName.Text = u.FullName ?? "";
            txtEmail.Text = u.Email ?? "";
        }

        // ================= LOAD EVENTS =================
        void LoadEvents()
        {
            cbEvent.DataSource = db.Events.ToList();
            cbEvent.DisplayMember = "Title";
            cbEvent.ValueMember = "EventID";
        }

        // ================= LOAD HISTORY =================
        void LoadHistory()
        {
            var history = db.EventRegistrations
                .Where(x => x.UserID == userID)
                .Select(x => new
                {
                    EventName = x.Event.Title,
                    Status = x.IsCheckedIn == true ? "Đã tham gia" : "Vắng mặt"
                })
                .ToList();

            dgvHistory.DataSource = history;
        }

        // ================= SAVE =================
        private void btnSave_Click(object sender, EventArgs e)
        {
            var u = db.Users.FirstOrDefault(x => x.UserID == userID);

            if (u == null)
            {
                MessageBox.Show("Không tìm thấy!");
                return;
            }

            u.StudentID = txtMSSV.Text;
            u.FullName = txtName.Text;
            u.Email = txtEmail.Text;

            db.SubmitChanges();

            MessageBox.Show("Cập nhật thành công!");
        }

        // ================= REGISTER + SEND EMAIL =================
        private void btnRegister_Click(object sender, EventArgs e)
        {
            var ev = cbEvent.SelectedItem as Event;

            if (ev == null)
            {
                MessageBox.Show("Vui lòng chọn sự kiện!");
                return;
            }

            // kiểm tra đã đăng ký chưa
            bool exist = db.EventRegistrations
                .Any(x => x.UserID == userID && x.EventID == ev.EventID);

            if (exist)
            {
                MessageBox.Show("Bạn đã đăng ký sự kiện này rồi!");
                return;
            }

            // lưu DB + FIX QR UNIQUE
            var reg = new EventRegistration
            {
                UserID = userID,
                EventID = ev.EventID,
                IsCheckedIn = false,
                QRCodeString = Guid.NewGuid().ToString() // ✅ FIX LỖI UNIQUE
            };

            db.EventRegistrations.InsertOnSubmit(reg);
            db.SubmitChanges(); // ✅ LƯU THÀNH CÔNG

            // gửi email
            SendEmail(ev);

            MessageBox.Show("Đăng ký thành công + đã gửi email!");

            LoadHistory();
        }

        // ================= SEND EMAIL =================
        void SendEmail(Event ev)
        {
            try
            {
                var user = db.Users.FirstOrDefault(x => x.UserID == userID);

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("test@mailtrap.io"); // dùng Mailtrap
                mail.To.Add(user.Email);
                mail.Subject = "Xác nhận đăng ký sự kiện";

                mail.Body = $@"
                    Bạn đã đăng ký thành công!

                    Tên sự kiện: {ev.Title}
                    Thời gian: {ev.StartTime:dd/MM/yyyy HH:mm} - {ev.EndTime:HH:mm}
                    Địa điểm: {ev.Location}

                    Cảm ơn bạn!
                    ";

                SmtpClient smtp = new SmtpClient("sandbox.smtp.mailtrap.io", 2525);
                smtp.Credentials = new NetworkCredential(
                    "4464c0f4213481",
                    "1084bc0d1e369b"
                );
                smtp.EnableSsl = true;

                smtp.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi gửi mail: " + ex.Message);
            }
        }

        // ================= COLOR STATUS =================
        private void dgvHistory_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvHistory.Columns[e.ColumnIndex].Name == "colStatus")
            {
                if (e.Value != null)
                {
                    if (e.Value.ToString() == "Đã tham gia")
                        e.CellStyle.ForeColor = Color.Green;
                    else
                        e.CellStyle.ForeColor = Color.Red;
                }
            }
        }
    }
}