﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace agile1
{
    public partial class Form1 : Form
    {
        databaseDataContext db = new databaseDataContext();
        public int currentRole = 1; // 1 = Admin, 2 = User

        public Form1()
        {
            InitializeComponent();
            LoadData();
            LoadKhoa();
        }

        // ================= LOAD =================
        void LoadData()
        {
            var ds = db.Users
                .Where(u => u.RoleID == 3)
                .Select(u => new
                {
                    u.UserID,
                    StudentID = u.StudentID,
                    FullName = u.FullName,
                    Email = u.Email
                }).ToList();

            dgvStudent.DataSource = ds;

            // Ẩn UserID (nhưng vẫn dùng được)
            if (dgvStudent.Columns["UserID"] != null)
                dgvStudent.Columns["UserID"].Visible = false;
        }

        void LoadKhoa()
        {
            cbKhoa.Items.Clear();
            cbKhoa.Items.Add("48");
            cbKhoa.Items.Add("49");
            cbKhoa.Items.Add("50");
        }

        // ================= CLICK GRID =================
        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (currentRole != 1)
            {
                MessageBox.Show("Bạn không có quyền truy cập!");
                return;
            }

            // ✅ FIX LỖI: lấy UserID bằng DataBoundItem
            dynamic row = dgvStudent.Rows[e.RowIndex].DataBoundItem;
            int userID = row.UserID;

            StudentDetail f = new StudentDetail(userID);
            f.ShowDialog();

            LoadData(); // refresh lại sau khi edit
        }

        // ================= FILTER KHOA =================
        private void btnFilter_Click(object sender, EventArgs e)
        {
            if (cbKhoa.SelectedItem == null) return;

            string khoa = cbKhoa.SelectedItem.ToString();

            var ds = db.Users
                .Where(u => u.RoleID == 3 && u.StudentID.StartsWith(khoa))
                .Select(u => new
                {
                    u.UserID,
                    StudentID = u.StudentID,
                    FullName = u.FullName,
                    Email = u.Email
                }).ToList();

            dgvStudent.DataSource = ds;

            // Ẩn lại UserID sau filter
            if (dgvStudent.Columns["UserID"] != null)
                dgvStudent.Columns["UserID"].Visible = false;
        }

        // FIX lỗi designer
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}