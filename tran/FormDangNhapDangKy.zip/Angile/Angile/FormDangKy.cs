﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Angile
{
    public partial class FormDangKy : Form
    {
        public FormDangKy()
        {
            InitializeComponent();
        }

        private void lblHovaTen_Click(object sender, EventArgs e)
        {

        }

        private void txtTenDangNhap_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMSSV_Click(object sender, EventArgs e)
        {

        }

        private void txtMSSV_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMatKhau_Click(object sender, EventArgs e)
        {

        }

        private void txtMatKhau_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            string hoTen = txtHovaTen.Text.Trim();
            string mssv = txtMSSV.Text.Trim();
            string email = txtEmail.Text.Trim();
            string matKhau = txtMatKhau.Text.Trim();

            // Không để trống
            if (string.IsNullOrEmpty(hoTen) || string.IsNullOrEmpty(mssv) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(matKhau))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //định dạng mssv xx.xx.xxx.xxx
            string patternMSSV = @"^\w{2}\.\w{2}\.\w{3}\.\w{3}$";
            if (!Regex.IsMatch(mssv, patternMSSV))
            {
                MessageBox.Show("Mã số sinh viên không đúng!\n(Ví dụ: 49.01.101.001)", "Lỗi định dạng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // định dang email
            if (!email.EndsWith("@gmail.com", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Email không đúng!", "Lỗi định dạng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var db = new DatabaseDataContext())
            {
                // Kiểm tra trùng lặp
                bool daTonTai = db.Users.Any(u => u.StudentID == mssv || u.Email == email);
                if (daTonTai)
                {
                    MessageBox.Show("Mã số sinh viên hoặc Email đã được đăng ký. Vui lòng kiểm tra lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Tạo đối tượng User mới
                User newUser = new User()
                {
                    FullName = hoTen,
                    StudentID = mssv,
                    Email = email,
                    PasswordHash = matKhau,
                    RoleID = 3,             // Sinh viên
                    IsActive = true
                };

                // Lệnh lưu vào CSDL của LINQ to SQL
                db.Users.InsertOnSubmit(newUser);
                db.SubmitChanges();

                MessageBox.Show("Đăng ký tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Trở về Form Đăng Nhập
                FormDangNhap frmDangNhap = new FormDangNhap();
                frmDangNhap.Show();
                this.Close();
            }
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            FormDangNhap frmDangNhap = new FormDangNhap();
            frmDangNhap.Show();
            this.Close();
        }

        private void chkHienMatKhau_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHienMatKhau.Checked)
            {
                txtMatKhau.PasswordChar = '\0';
            }
            else
            {
                //ẩn mk
                txtMatKhau.PasswordChar = '*';
            }
        }
    }
}
